<?php
/**
 * @version		$Id: information.php 3750 2014-09-28 16:22:31Z mic $
 * @package		Translation Deutsch
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Text
$_['text_error']	= 'Leider konnte die gesuchte Seite nicht gefunden werden - eventuell ein Tippfehler?';