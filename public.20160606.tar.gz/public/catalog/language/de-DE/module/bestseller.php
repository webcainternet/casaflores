<?php
/**
 * @version		$Id: bestseller.php 3721 2014-08-18 13:37:29Z mic $
 * @package		Translation - Frontend
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Heading
$_['heading_title']	= 'Bestseller';
// Text
$_['text_tax']		= 'ohne Steuer';