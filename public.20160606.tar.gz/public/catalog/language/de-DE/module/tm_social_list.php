<?php
// Text
$_['text_heading'] = 'Folgen Sie uns';