<?php
/**
 * @version		$Id: upload.php 3721 2014-08-18 13:37:29Z mic $
 * @package		Translation Frontend
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Text
$_['text_upload']		= 'Datei erfolgreich hochgeladen';

// Error
$_['error_filename']	= 'Dateiname muss zischen 3 und 64 Zeichen lang sein';
$_['error_filetype']	= 'Ungültige Dateiart';
$_['error_upload']		= 'Upload erforderlich';