<?php
/**
 * @version		$Id: pp_standard.php 3721 2014-08-18 13:37:29Z mic $
 * @package		Translation Frontend
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Text
$_['text_title']	= 'PayPal';
$_['text_reason']	= 'GRUND';
$_['text_testmode']	= 'ACHTUNG!!! Diese Zahlungsart befindet sich momentan im <b>Testmodus</b> - es werden keine realen Zahlungen durchgeführt.';
$_['text_total']	= 'Versand, Bearbeitung, Gutschrift und Steuern';