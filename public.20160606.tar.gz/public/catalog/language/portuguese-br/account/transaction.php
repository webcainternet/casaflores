<?php
// Heading
$_['heading_title']      = 'Transações';

// Column
$_['column_date_added']  = 'Cadastro';
$_['column_description'] = 'Descrição';
$_['column_amount']      = 'Valor (%s)';

// Text
$_['text_account']       = 'Minha conta';
$_['text_transaction']   = 'Transações';
$_['text_total']         = 'Seu saldo é:';
$_['text_empty']         = 'Não há registro de transações!';