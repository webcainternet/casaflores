<?php
// Text
$_['text_success']     = 'Os pontos foram utilizados com sucesso!';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão de acesso a API!';
$_['error_reward']     = 'Atenção: Insira a quantidade de pontos que deseja utilizar!';
$_['error_points']     = 'Atenção: Você não possui %s pontos!';
$_['error_maximum']    = 'Atenção: O número máximo de pontos que pode ser utilizado é: %s!';