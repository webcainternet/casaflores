<?php
// Text
$_['text_reward']   = 'Pontos (%s)';
$_['text_order_id'] = 'Pedido nยบ: %s';