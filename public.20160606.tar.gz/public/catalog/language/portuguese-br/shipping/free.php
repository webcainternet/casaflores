<?php
// Text
$_['text_title']       = 'Grátis';
$_['text_description'] = 'Frete grátis';