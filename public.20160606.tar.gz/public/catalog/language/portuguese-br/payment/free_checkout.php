<?php
// Text
$_['text_title'] = 'Pagamento grátis';