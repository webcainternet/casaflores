<?php
// Text
$_['text_subject']	= '%s - Novo comentário';
$_['text_waiting']	= 'Um novo comentário foi cadastrado e está aguardando aprovação.';
$_['text_product']	= 'Produto: %s';
$_['text_reviewer']	= 'Autor: %s';
$_['text_rating']	= 'Avaliação: %s';
$_['text_review']	= 'Comentário:';