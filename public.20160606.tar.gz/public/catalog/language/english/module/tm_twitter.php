<?php
// Heading
$_['heading_title']    = 'Twitter Timeline';

// Text
$_['text_edit']        = 'Edit Account';
